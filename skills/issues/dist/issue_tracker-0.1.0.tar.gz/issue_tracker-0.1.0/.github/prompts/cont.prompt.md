# Continue work

- Focus on issues in `.work/agent/issues/shortlist.md`
- Then work on issues according to priority in `.work/agent/issues/`
- **IMPORTANT** Remember to mark completed tasks as you go
- Running `uv run scripts/build.py --verbose` should produce no errors, warnings or failures
- Any issues reported by the build script should be improved, even if they are not related to your direct changes.