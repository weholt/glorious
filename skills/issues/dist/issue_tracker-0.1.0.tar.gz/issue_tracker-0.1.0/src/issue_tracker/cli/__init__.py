"""CLI package initialization."""

from issue_tracker.cli.app import app

__all__ = ["app"]
