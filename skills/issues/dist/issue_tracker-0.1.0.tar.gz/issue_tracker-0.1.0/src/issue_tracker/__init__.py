"""Git-backed issue tracking with hash IDs and MCP server."""

__version__ = "0.1.0"
