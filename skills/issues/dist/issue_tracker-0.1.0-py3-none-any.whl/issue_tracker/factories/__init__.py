"""Factories package."""

from issue_tracker.factories.service_factory import ServiceFactory

__all__ = ["ServiceFactory"]
